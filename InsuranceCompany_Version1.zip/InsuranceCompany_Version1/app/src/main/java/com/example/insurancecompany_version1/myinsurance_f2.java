package com.example.insurancecompany_version1;

public class myinsurance_f2 {

    private String fragment2_item_date_input;
    private String fragment2_item_name_input;
    private int fragment2_item_image;
    private String fragment2_item_date;
    private String fragment2_item_name;

    public myinsurance_f2(String fragment2_item_date_input, String fragment2_item_name_input, int fragment2_item_image, String fragment2_item_date, String fragment2_item_name){
        this.fragment2_item_date_input = fragment2_item_date_input;
        this.fragment2_item_name_input = fragment2_item_name_input;
        this.fragment2_item_image = fragment2_item_image;
        this.fragment2_item_date = fragment2_item_date;
        this.fragment2_item_name = fragment2_item_name;
    }

    public String getFragment2_item_date_input(){
        return fragment2_item_date_input;
    }

    public void setFragment2_item_date_input(String fragment2_item_date_input){
        this.fragment2_item_date_input = fragment2_item_date_input;
    }

    public String getFragment2_item_name_input(){
        return fragment2_item_name_input;
    }

    public void setFragment2_item_name_input(String fragment2_item_name_input){
        this.fragment2_item_name_input = fragment2_item_name_input;
    }

    public int getFragment2_item_image(){
        return fragment2_item_image;
    }

    public void setFragment2_item_image(int fragment2_item_image){
        this.fragment2_item_image = fragment2_item_image;
    }

    public String getFragment2_item_date(){
        return fragment2_item_date;
    }

    public void setFragment2_item_date(String fragment2_item_date){
        this.fragment2_item_date = fragment2_item_date;
    }

    public String getFragment2_item_name(){
        return fragment2_item_name;
    }

    public void setFragment2_item_name(String fragment2_item_name){
        this.fragment2_item_name = fragment2_item_name;
    }

}
